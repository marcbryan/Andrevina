package com.andrevina.et.andrevina;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final int numero = (int) (Math.random()*100)+1;
        final Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

               // int num1 = numIntro.getNumber();
                TextView tv;
                //tv = (TextView) findViewById(R.id.textView);
                tv = (TextView) findViewById(R.id.numIntro);
                String tvValue = tv.getText().toString();
                System.out.println(tvValue);

                Context context = getApplicationContext();
                CharSequence text = "";
                int duration = Toast.LENGTH_LONG;



                if (!tvValue.equals("")) {
                    int num1 = Integer.parseInt(tvValue);
                    if (num1 < numero){
                        text = "El numero es mas grande";
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }
                    else if (num1 > numero){
                        text = "El numero es mas pequeño";
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }
                    else if (num1 == numero) {
                        text = "Has acertado!";
                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }
                }
            }
        });
    }
}
